"""Raven 3D game engine (M0 technical prototype)."""
__version__ = "0.0.1"
