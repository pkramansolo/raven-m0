"""Dockable Qt shell used to test the desktop editor architecture."""
from PySide6.QtCore import Qt
from PySide6.QtWidgets import QDockWidget, QLabel, QMainWindow, QPlainTextEdit, QTreeWidget, QTreeWidgetItem

class RavenWindow(QMainWindow):
    """M0 window with draggable docks; not yet a scene editor."""

    def __init__(self) -> None:
        super().__init__()
        self.setWindowTitle("Raven — M0 Integration Prototype")
        self.resize(1200, 760)
        self.setDockNestingEnabled(True)
        self.viewport_placeholder = QLabel("3D viewport integration is under evaluation.\nRun raven-m0-panda for a real 3D window.")
        self.viewport_placeholder.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.viewport_placeholder.setStyleSheet("background:#151a24;color:#c5d0e0;font-size:17px;")
        self.setCentralWidget(self.viewport_placeholder)
        scene = QTreeWidget()
        scene.setHeaderLabel("Scene (demonstration only)")
        QTreeWidgetItem(scene, ["Main (placeholder)"])
        self._dock("Scene Tree", scene, Qt.DockWidgetArea.LeftDockWidgetArea)
        self._dock("Inspector", QLabel("Select a node in a future milestone"), Qt.DockWidgetArea.RightDockWidgetArea)
        self.console = QPlainTextEdit()
        self.console.setReadOnly(True)
        self.console.setPlainText("Raven M0 started. Qt docking smoke test ready.\nNo engine features are implemented yet.")
        self._dock("Console", self.console, Qt.DockWidgetArea.BottomDockWidgetArea)

    def _dock(self, title: str, widget, area: Qt.DockWidgetArea) -> None:
        """Create a movable, closable editor dock."""
        dock = QDockWidget(title, self)
        dock.setObjectName(title.replace(" ", ""))
        dock.setWidget(widget)
        dock.setAllowedAreas(Qt.DockWidgetArea.AllDockWidgetAreas)
        self.addDockWidget(area, dock)
