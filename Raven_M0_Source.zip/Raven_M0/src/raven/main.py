"""Start the M0 Qt desktop prototype."""
import sys
from PySide6.QtWidgets import QApplication
from raven.editor.main_window import RavenWindow

def main() -> int:
    """Run the M0 desktop shell and return the Qt exit code."""
    app = QApplication.instance() or QApplication(sys.argv)
    app.setApplicationName("Raven M0")
    window = RavenWindow()
    window.show()
    return app.exec()

if __name__ == "__main__":
    raise SystemExit(main())
