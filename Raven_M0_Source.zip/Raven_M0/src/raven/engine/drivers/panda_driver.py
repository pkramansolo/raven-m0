"""Only Raven module that imports Panda3D; standalone M0 rendering test."""
from math import sin, cos, pi
from direct.showbase.ShowBase import ShowBase
from panda3d.core import AmbientLight, DirectionalLight, Geom, GeomNode, GeomTriangles, GeomVertexData, GeomVertexFormat, GeomVertexWriter, Vec4

class PandaSmokeDriver(ShowBase):
    """Standalone Panda3D renderer with cube and basic keyboard camera controls."""

    def __init__(self) -> None:
        super().__init__()
        self.disableMouse()
        self.setBackgroundColor(0.08, 0.11, 0.17, 1)
        self.camera.setPos(5, -9, 5)
        self.camera.lookAt(0, 0, 0)
        self.cube = self.render.attachNewNode(self._make_cube())
        self.cube.setColor(0.35, 0.65, 1.0, 1)
        ambient = AmbientLight("ambient")
        ambient.setColor(Vec4(.38, .38, .38, 1))
        self.render.setLight(self.render.attachNewNode(ambient))
        sun = DirectionalLight("sun")
        sun.setColor(Vec4(.85, .85, .85, 1))
        sun_node = self.render.attachNewNode(sun)
        sun_node.setHpr(-30, -50, 0)
        self.render.setLight(sun_node)
        self.keys = set()
        for key in ("w", "a", "s", "d", "q", "e"):
            self.accept(key, self._set_key, [key, True])
            self.accept(key + "-up", self._set_key, [key, False])
        self.accept("escape", self.userExit)
        self.taskMgr.add(self._tick, "raven-m0-tick")

    def _set_key(self, key: str, down: bool) -> None:
        """Track movement keys."""
        (self.keys.add if down else self.keys.discard)(key)

    def _tick(self, task):
        """Rotate the cube and move the camera using frame delta."""
        dt = min(globalClock.getDt(), 0.1)
        self.cube.setH(self.cube.getH() + dt * 35)
        movement = {"w": (0, 5, 0), "s": (0, -5, 0), "a": (-5, 0, 0), "d": (5, 0, 0), "q": (0, 0, -5), "e": (0, 0, 5)}
        for key in self.keys:
            dx, dy, dz = movement[key]
            self.camera.setPos(self.camera, dx * dt, dy * dt, dz * dt)
        return task.cont

    @staticmethod
    def _make_cube() -> GeomNode:
        """Construct a cube procedurally without external model assets."""
        data = GeomVertexData("cube", GeomVertexFormat.getV3n3(), Geom.UHStatic)
        vertex = GeomVertexWriter(data, "vertex")
        normal = GeomVertexWriter(data, "normal")
        faces = [((0,-1,0), [(-1,-1,-1),(1,-1,-1),(1,-1,1),(-1,-1,1)]),
                 ((0,1,0), [(1,1,-1),(-1,1,-1),(-1,1,1),(1,1,1)]),
                 ((-1,0,0), [(-1,1,-1),(-1,-1,-1),(-1,-1,1),(-1,1,1)]),
                 ((1,0,0), [(1,-1,-1),(1,1,-1),(1,1,1),(1,-1,1)]),
                 ((0,0,1), [(-1,-1,1),(1,-1,1),(1,1,1),(-1,1,1)]),
                 ((0,0,-1), [(-1,1,-1),(1,1,-1),(1,-1,-1),(-1,-1,-1)])]
        triangles = GeomTriangles(Geom.UHStatic)
        for i, (n, corners) in enumerate(faces):
            for point in corners:
                vertex.addData3f(*point)
                normal.addData3f(*n)
            j = i * 4
            triangles.addVertices(j, j+1, j+2)
            triangles.addVertices(j, j+2, j+3)
        geom = Geom(data)
        geom.addPrimitive(triangles)
        node = GeomNode("cube")
        node.addGeom(geom)
        return node

def run_panda_smoke() -> None:
    """Open the real 3D test window and block until it closes."""
    driver = PandaSmokeDriver()
    try:
        driver.run()
    finally:
        driver.destroy()

if __name__ == "__main__":
    run_panda_smoke()
