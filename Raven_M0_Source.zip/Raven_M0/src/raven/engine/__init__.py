"""Engine namespace, intentionally minimal in M0."""
