# RAVEN — Build Guide (Version 1)

A small, installable, **3D-only** Godot-style engine and editor, written **mostly in Python**.

This file is your step-by-step plan. Give the AI **one step at a time**, run the tests yourself, commit to Git, then move on.

---

## 0. Scope of Version 1

**Included**
- Home screen (project manager): create, open, recent projects
- Saved projects (folder + `project.raven` file)
- Scene tree with 3D nodes
- Inspector panel (properties of the selected node)
- 3D viewport
- Import 3D models (GLB/glTF from Blender) and images
- File system panel (browse the project's files)
- Script window (Python code editor) + attach scripts to nodes
- Common settings (project settings + editor preferences)
- Play button (runs the game in a separate window)
- Installable app (macOS `.app` first)

**Not included in Version 1** (do not build these yet)
- 2D nodes of any kind
- Asset library / store
- Animation, audio, navigation, particles, CSG, GridMap
- Debugger with breakpoints, hot reload, plugins
- Mesh modelling inside Raven (use Blender, import GLB)
- Export for other platforms, cloud, multiplayer

---

## 1. Technology choices (verify each in Phase 0 before relying on it)

| Need | Choice | Language | Why |
|---|---|---|---|
| Engine and editor logic | Python 3.11 or 3.12 (your `sparrow` environment) | Python | You asked for Python first |
| Editor UI | PySide6 (Qt) | Python | Docks, panels, trees, dialogs built in |
| 3D rendering | Panda3D | Python API (C++ inside) | Mature, installs with pip, runs on Apple Silicon (verify) |
| GLB/glTF loading | `panda3d-gltf` | Python | Loads Blender exports |
| Maths | NumPy | Python | Transforms, vectors |
| Settings folders | `platformdirs` | Python | Correct config folder per OS |
| Tests | pytest (+ pytest-qt for UI) | Python | Required for every step |
| Packaging | PyInstaller (or Briefcase) | Python | Makes an installable app |
| Physics (later) | Panda3D's built-in Bullet module | Python API | No extra language needed |

**When another language is allowed:** only if a measured problem cannot be solved in Python (for example, a physics or rendering speed limit). Until then, no C++/Rust of your own. Panda3D's internals are already C++, which you simply use.

**Rule:** your Node classes must NOT expose Panda3D objects to game scripts. Wrap them, so the renderer can be replaced later.

---

## 2. Rules to give the AI (save as `RULES.md` in the repo)

1. Read the existing repo before changing code.
2. Do exactly one step per request. Do not create files outside that step.
3. Never create duplicate classes. Follow the folder structure below.
4. Write complete, runnable code. No placeholders presented as finished.
5. Add pytest tests for every important behaviour. Run them. Fix failures.
6. Never claim something works unless you ran it. Show the test output.
7. Report: files created, files modified, tests run, known limitations.
8. Do not add dependencies without asking.
9. Keep Panda3D usage inside `engine/drivers/` only.
10. Python game scripts are **not sandboxed**. Never claim they are.

---

## 3. Folder structure

```
raven/
├── pyproject.toml
├── README.md
├── RULES.md
├── raven_launcher.py              # starts the editor app
│
├── engine/
│   ├── core/
│   │   ├── property.py            # property system (type, default, validation)
│   │   ├── signal.py              # Signal class
│   │   ├── object.py              # base object (properties + signals)
│   │   ├── node.py                # Node
│   │   ├── scene_tree.py          # SceneTree + lifecycle calls
│   │   ├── node_registry.py       # name -> class
│   │   ├── scene_io.py            # save/load scene JSON
│   │   └── transform.py           # NumPy transform maths
│   ├── nodes/
│   │   ├── node3d.py
│   │   ├── mesh_instance_3d.py
│   │   ├── camera_3d.py
│   │   ├── directional_light_3d.py
│   │   ├── omni_light_3d.py
│   │   ├── spot_light_3d.py
│   │   ├── world_environment.py
│   │   └── (physics nodes later)
│   ├── drivers/
│   │   └── panda_driver.py        # the ONLY place that touches Panda3D
│   ├── assets/
│   │   ├── import_pipeline.py
│   │   ├── model_importer.py
│   │   └── texture_importer.py
│   └── scripting/
│       ├── script_loader.py
│       └── script_api.py
│
├── settings/
│   ├── registry.py                # defines every setting
│   ├── project_settings.py
│   └── editor_preferences.py
│
├── project/
│   ├── project_file.py            # read/write project.raven
│   ├── project_manager.py         # create, open, validate, recent list
│   └── templates/empty_3d/
│
├── editor/
│   ├── main.py
│   ├── home_screen.py
│   ├── main_window.py
│   ├── panels/
│   │   ├── scene_tree_panel.py
│   │   ├── inspector_panel.py
│   │   ├── file_system_panel.py
│   │   ├── script_editor_panel.py
│   │   ├── console_panel.py
│   │   └── viewport_panel.py
│   ├── undo.py                    # QUndoStack commands
│   └── dialogs/
│       ├── new_project_dialog.py
│       ├── settings_dialog.py
│       └── import_dialog.py
│
├── runtime/
│   └── run_game.py                # runs a project WITHOUT the editor
│
├── tests/
└── documentation/
```

---

## 4. How a Raven project looks on disk

```
MyGame/
├── project.raven          # JSON: name, version, main scene, project settings
├── scenes/
│   └── main.scene.json
├── scripts/
│   └── player.py
├── assets/
│   ├── models/robot.glb
│   └── textures/grass.png
└── .raven/                # cache, import data (ignored by Git)
```

`project.raven` example:

```json
{
  "raven_format": 1,
  "name": "MyGame",
  "main_scene": "scenes/main.scene.json",
  "settings": {
    "display/window/width": 1280,
    "display/window/height": 720,
    "physics/gravity": 9.8
  }
}
```

Scene file example (`main.scene.json`):

```json
{
  "raven_format": 1,
  "root": {
    "type": "Node3D",
    "name": "Main",
    "properties": {},
    "children": [
      {"type": "Camera3D", "name": "Camera",
       "properties": {"position": [0, 2, 6], "fov": 70}, "children": []},
      {"type": "MeshInstance3D", "name": "Robot",
       "properties": {"mesh_path": "assets/models/robot.glb",
                      "script": "scripts/player.py"},
       "children": []}
    ]
  }
}
```

Rules: all paths inside a project are **relative** to the project folder. A project can only read and write inside its own folder.

---

# PHASES AND STEPS

Each step lists: **What**, **Files**, **How it works**, **Done when**.

## PHASE 0 — Prove the risky parts (1 to 3 days)

Before building anything, confirm each tool works on your MacBook Air M4.

**0.1 Environment**
- Activate `sparrow`. Check `python --version` (3.11 or 3.12).
- Install: `pyside6 panda3d panda3d-gltf numpy pytest pytest-qt platformdirs`
- Done when: `pip list` shows all, and `import PySide6, panda3d, numpy` works.

**0.2 Qt window spike** (throwaway file `spikes/qt_window.py`)
- Open a window with a dock panel on each side.
- Done when: the window opens, docks can be dragged.

**0.3 Panda3D window spike** (`spikes/panda_cube.py`)
- Open a Panda3D window, load a GLB (export a cube or monkey from Blender), rotate it.
- Done when: the model shows on screen on your M4.

**0.4 Viewport embedding decision** (`spikes/embed_test.py`)
- Try putting the 3D view *inside* a Qt panel. Two common approaches to test:
  1. Give Panda3D the Qt widget's native window handle as its parent.
  2. Render Panda3D offscreen to an image and display it in a Qt widget.
- Done when: you know which works on macOS. **If neither works well, Version 1 uses a separate viewport window.** This is acceptable.
- Write the result in `documentation/decisions.md`.

---

## PHASE 1 — Engine core (no graphics, fully testable)

**1.1 Repo setup**
- Files: `pyproject.toml`, `RULES.md`, `README.md`, empty package folders with `__init__.py`, `tests/`.
- Git init, `.gitignore` (include `.raven/`, `__pycache__/`).
- Done when: `pytest` runs (0 tests is fine) and first commit exists.

**1.2 Property system** — `engine/core/property.py`
- A property has: name, type, default, validation (min/max, allowed values), category, editor hint (e.g. "color", "file", "slider").
- Supported types: bool, int, float, str, Vector3, Color, enum, file path.
- How it works: a node class declares properties; the Inspector later reads this list automatically.
- Done when: tests prove default values, type errors, out-of-range rejection.

**1.3 Signal** — `engine/core/signal.py`
- `connect(callable)`, `disconnect(callable)`, `emit(*args)`.
- Done when: tests cover connect, emit, disconnect, two listeners, listener that raises an error (does not stop the others).

**1.4 Base object** — `engine/core/object.py`
- Holds properties and a `property_changed` signal.
- `get(name)`, `set(name, value)` (validates, emits signal).
- Done when: setting a property fires the signal once.

**1.5 Node** — `engine/core/node.py`
- Name, parent, children, `add_child`, `remove_child`, `get_node(path)`, `get_children`, `queue_free`.
- Lifecycle methods: `_enter_tree`, `_ready`, `_process(delta)`, `_physics_process(delta)`, `_exit_tree`.
- Unique sibling names (auto-rename `Cube`, `Cube2`).
- Done when: tests cover tree building, reparenting, duplicate names, path lookup.

**1.6 SceneTree + game loop** — `engine/core/scene_tree.py`
- Owns the root node. `step(delta)` calls `_process` on every node, `_physics_process` at a fixed rate (default 60 Hz).
- Calls `_ready` once, children first.
- Done when: a test builds 3 nodes, runs 10 steps, and counts the calls in the right order.

**1.7 Transform maths** — `engine/core/transform.py`
- 4x4 matrix from position, rotation (Euler degrees), scale using NumPy.
- Done when: tests check known values (e.g. 90° rotation) and composing parent × child.

**1.8 Node3D** — `engine/nodes/node3d.py`
- Properties: `position`, `rotation`, `scale`, `visible`.
- Methods: `global_transform`, `look_at`, `translate`, `rotate_y`.
- Done when: a child's global position follows its parent's movement.

**1.9 Node registry** — `engine/core/node_registry.py`
- Decorator `@register_node("Node3D")`. `create("Node3D")` returns an instance.
- Provides a list of node types and their parent classes (for the "Add Node" dialog).
- Done when: unknown names raise a clear error; list is sorted.

**1.10 Scene save/load** — `engine/core/scene_io.py`
- Save tree to JSON and load it back. Only saves properties that differ from defaults.
- Done when: round-trip test gives an identical tree. Bad JSON gives a clear error, not a crash.

**1.11 Settings registry** — `settings/registry.py`, `project_settings.py`, `editor_preferences.py`
- Registry holds every setting: id, type, default, min/max, category, description.
- Two separate stores: project settings (inside `project.raven`) and editor preferences (in the user config folder from `platformdirs`).
- Done when: settings save, reload, reject invalid values, and fall back to defaults if the file is missing or corrupt.

---

## PHASE 2 — Projects (create, open, save)

**2.1 Project file** — `project/project_file.py`
- Read/write/validate `project.raven`. Check `raven_format` version.
- Done when: missing file, bad JSON, wrong version each give a specific error message.

**2.2 Create project** — `project/project_manager.py`
- `create_project(name, location, template)`: makes the folder, copies template, writes `project.raven`, creates a starter scene (a `Node3D` root with a Camera3D and DirectionalLight3D).
- Refuse: empty name, illegal characters, folder that already exists and is not empty.
- Done when: tests create a project in a temp folder and reload it.

**2.3 Open and validate**
- `open_project(path)` checks the file and the folders, returns a Project object.
- Done when: opening a missing/invalid folder returns a friendly error.

**2.4 Recent projects**
- Stored in editor preferences. Max 15. Remove entries whose folder no longer exists (show them greyed out instead of crashing).
- Done when: tests cover add, reorder, dedupe, missing folder.

**2.5 Save**
- `save_scene()` and `save_project()`. Write to a temp file, then rename, so a crash cannot corrupt the file.
- Done when: a test interrupts a save and the old file is intact.

---

## PHASE 3 — Home screen (Project Manager window)

**3.1 App entry** — `raven_launcher.py`, `editor/main.py`
- Starts `QApplication`, loads editor preferences, shows the home screen.

**3.2 Home screen layout** — `editor/home_screen.py`
- Left: list of recent projects (name, path, last opened).
- Buttons: **New Project**, **Open Project**, **Remove from list**, **Settings**.
- Double-click a project opens it.

**3.3 New Project dialog** — `editor/dialogs/new_project_dialog.py`
- Fields: project name, location (folder picker), template (Empty 3D).
- Live validation message under the fields. Create button is disabled until valid.

**3.4 Open Project**
- Folder picker, validate, open. Show an error dialog when invalid.

**3.5 Open the editor**
- When a project opens, close the home screen and open the main window with that project.
- Done when (Phase 3): you can create a project, close Raven, relaunch, see it in Recent, and open it.

---

## PHASE 4 — Main editor window

**4.1 Layout** — `editor/main_window.py`
- Toolbar on top: Save, Undo, Redo, Play, Stop, Settings.
- Left dock: Scene tree. Center: Viewport. Right dock: Inspector.
- Bottom docks (tabs): File System, Script Editor, Console.
- Save/restore window layout using `QMainWindow.saveState()` in editor preferences.

**4.2 Undo/redo foundation** — `editor/undo.py`
- Use `QUndoStack`. Commands: `SetProperty`, `AddNode`, `DeleteNode`, `RenameNode`, `ReparentNode`.
- Rule: every editor change to scene data goes through a command.
- Done when: tests undo and redo each command.

**4.3 Scene tree panel** — `editor/panels/scene_tree_panel.py`
- Shows the real node tree (not a copy of demo data).
- Add node (dialog listing registered nodes with a search box), delete, rename (F2), drag to reparent, search filter.
- Selecting a node emits `node_selected`.

**4.4 Inspector panel** — `editor/panels/inspector_panel.py`
- When a node is selected, build the property list from its property definitions.
- Widget per type:

| Property type | Widget |
|---|---|
| bool | checkbox |
| int | spin box |
| float | decimal spin box |
| str | line edit |
| Vector3 | three decimal boxes (X, Y, Z) |
| Color | colour button + dialog |
| enum | drop-down |
| file path | line edit + browse button |

- Groups by category (Transform, Rendering, Script, etc.).
- Every edit goes through `SetProperty` (so undo works).
- A node's script shown in a "Script" field with an **open** button.
- Done when: changing Position X in the Inspector changes the node, and Ctrl+Z reverts it.

**4.5 Console panel** — `editor/panels/console_panel.py`
- Shows logs from the editor and from the running game (info, warning, error with colours). Clear button.

---

## PHASE 5 — 3D viewport and first nodes

**5.1 Panda driver** — `engine/drivers/panda_driver.py`
- The only file importing Panda3D. Functions: create window/scene, create/destroy model, set transform, set camera, set light, load GLB, render frame.
- Done when: a standalone test script shows a cube controlled through the driver API.

**5.2 MeshInstance3D** — `engine/nodes/mesh_instance_3d.py`
- Properties: `mesh_path` (GLB or built-in primitive: Box, Sphere, Cylinder, Plane), `cast_shadow`, `material_color`.
- When added to the tree, asks the driver to create the visual. Follows the node's global transform.

**5.3 Camera3D** — `engine/nodes/camera_3d.py`
- Properties: `fov`, `near`, `far`, `projection` (perspective/orthographic), `current`.

**5.4 Lights**
- `DirectionalLight3D`: `color`, `energy`, `shadow_enabled`.
- `OmniLight3D`: `color`, `energy`, `range`.
- `SpotLight3D`: `color`, `energy`, `range`, `angle`.
- `WorldEnvironment`: `background_color`, `ambient_color`, `ambient_energy`.

**5.5 Viewport panel** — `editor/panels/viewport_panel.py`
- Use the method chosen in step 0.4 (embedded, or separate window for now).
- Editor camera: right-mouse look + WASD, scroll to zoom, middle-mouse pan.
- Grid on the floor, selection highlight.
- Click an object to select it (the Scene tree and Inspector follow).

**5.6 Basic gizmos**
- Move, rotate, scale modes (keys W, E, R). Dragging changes the node's property through `SetProperty`.
- Start with move only. Add rotate and scale afterwards.
- Optional: snapping toggle.

Done when (Phase 5): add a MeshInstance3D from the Add Node dialog, see a cube, move it in the viewport, see the Inspector update, undo it.

---

## PHASE 6 — Import and file access

**6.1 File system panel** — `editor/panels/file_system_panel.py`
- Tree view of the project folder (`QFileSystemModel`), icons per type.
- Right-click: new folder, new script, rename, delete (with confirmation), show in Finder.
- Watches the folder with `QFileSystemWatcher` so new files appear automatically.
- **Safety:** every path must resolve to inside the project folder. Reject `..` tricks and symlinks that leave the folder.

**6.2 Import pipeline** — `engine/assets/import_pipeline.py`
- When a file appears in `assets/`: decide the importer by extension, write `.raven/imports/<name>.import.json` (scale, up-axis, etc.).
- Supported in Version 1: `.glb`, `.gltf`, `.png`, `.jpg`, `.jpeg`, `.webp`.
- Importer errors are shown in the console, not as crashes.

**6.3 Model import** — `engine/assets/model_importer.py`
- Validate the GLB loads. Read basic info (mesh count, size).
- Import settings: scale (default 1.0), up axis (Y-up default).
- **Re-import** when the source file changes (compare modified time/hash).

**6.4 Import dialog and drag-drop** — `editor/dialogs/import_dialog.py`
- Drag a file from Finder into the File System panel (copies it into `assets/`).
- Drag a model from the File System panel into the viewport or Scene tree: creates a `MeshInstance3D` with `mesh_path` set.

**6.5 Blender workflow (documented)**
- In Blender: File → Export → glTF 2.0 (.glb), into the project's `assets/models/`.
- Do NOT write a `.blend` parser. Optional later: a button that runs Blender in the background to export (`blender --background file.blend --python export.py`).

Done when: export a model from Blender, drag it into Raven, it appears in the viewport, you re-export a changed version and it updates.

---

## PHASE 7 — Script window and scripting

**7.1 Script editor panel** — `editor/panels/script_editor_panel.py`
- Tabs for open files. Line numbers, Python syntax highlighting (`QSyntaxHighlighter`), save (Cmd+S), modified marker, find.
- Opens from: the File System panel (double-click `.py`), the Inspector's Script open button.

**7.2 Create script**
- Right-click in File System → New Script → creates `scripts/<name>.py` from a template:

```python
from raven import Node3D

class Player(Node3D):
    speed = 5.0

    def _ready(self):
        print("Player ready")

    def _process(self, delta):
        self.rotate_y(45 * delta)
```

**7.3 Script loader** — `engine/scripting/script_loader.py`
- Loads the file with `importlib`, finds the class that extends the node's type, creates an instance bound to the node.
- Syntax or runtime errors are caught, logged with file and line, and do **not** crash the editor.
- Exceptions inside `_process` are logged once per second, not every frame.

**7.4 Attach script**
- Node property `script` (file path). Inspector "Script" field with Attach, Detach, Open.
- Done when: a node with an attached script rotates when Play is pressed.

**7.5 Script API** — `engine/scripting/script_api.py`
- Public names for scripts (`from raven import ...`): `Node`, `Node3D`, `MeshInstance3D`, `Camera3D`, `Input`, `Signal`, `print`.
- `Input`: `is_key_pressed("w")`, `get_axis("left", "right")`, `get_mouse_delta()`.
- Script methods: `get_node("path")`, `get_parent()`, `add_child()`, `queue_free()`.
- Document each function in `documentation/script_api.md`.

**7.6 Safety note**
- Scripts run with full Python permissions. Do not open untrusted projects. Show a one-time warning when opening a project from outside your own folders.

---

## PHASE 8 — Settings dialogs

Settings come from the registry (step 1.11). The dialog is built automatically from it.

**8.1 Settings dialog** — `editor/dialogs/settings_dialog.py`
- Two tabs: **Project Settings** and **Editor Preferences**.
- Search box. Categories on the left. Widgets by type (same mapping as the Inspector).
- "Reset to default" per setting. Validation errors shown inline.

**8.2 Initial settings (register these)**

Project settings:

| Id | Type | Default | Used by |
|---|---|---|---|
| `application/name` | str | project name | window title |
| `application/main_scene` | file | scenes/main.scene.json | Play |
| `display/window/width` | int (320–7680) | 1280 | game window |
| `display/window/height` | int (240–4320) | 720 | game window |
| `display/window/fullscreen` | bool | false | game window |
| `display/window/resizable` | bool | true | game window |
| `display/vsync` | bool | true | renderer |
| `rendering/shadows_enabled` | bool | true | renderer |
| `rendering/antialiasing` | enum (off/2x/4x) | 2x | renderer |
| `physics/gravity` | float | 9.8 | physics (later) |
| `physics/tick_rate` | int (10–240) | 60 | SceneTree |
| `input/actions` | dict | move_left/right/forward/back | Input |

Editor preferences:

| Id | Type | Default |
|---|---|---|
| `interface/theme` | enum (dark/light) | dark |
| `interface/font_size` | int | 13 |
| `viewport/camera_speed` | float | 5.0 |
| `viewport/grid_visible` | bool | true |
| `viewport/snap_enabled` | bool | false |
| `viewport/snap_step` | float | 0.5 |
| `code/font_size` | int | 13 |
| `code/indent_size` | int | 4 |
| `code/show_line_numbers` | bool | true |
| `files/external_blender_path` | file | empty |

Rule: a setting only exists if something reads it. Do not add decorative settings.

---

## PHASE 9 — Play, Stop, and the runtime

**9.1 Runtime runner** — `runtime/run_game.py`
- `python -m runtime.run_game <project_path>`: loads project settings, loads the main scene, opens a game window at the configured size, runs the SceneTree loop. **Does not import anything from `editor/`.**

**9.2 Play button**
- Editor starts the runner as a separate process (`subprocess`), saves the scene first, and reads its output into the Console panel. Stop kills the process.
- Runtime errors show in the Console with file and line.
- Why a separate process: a crashing game can't crash the editor.

**9.3 Pause**
- Optional for Version 1. Skip if it adds complexity.

Done when: Play opens a game window with your scene, the script moves the object, Stop closes it.

---

## PHASE 10 — Remaining Version-1 nodes

Only after Phases 1 to 9 work. Add one at a time with tests, each as its own file.

| Node | Parent | Key properties |
|---|---|---|
| `Node` | Object | name, script |
| `Node3D` | Node | position, rotation, scale, visible |
| `Marker3D` | Node3D | (none; a position helper) |
| `MeshInstance3D` | Node3D | mesh_path, cast_shadow, material_color |
| `Camera3D` | Node3D | fov, near, far, projection, current |
| `DirectionalLight3D` | Node3D | color, energy, shadow_enabled |
| `OmniLight3D` | Node3D | color, energy, range |
| `SpotLight3D` | Node3D | color, energy, range, angle |
| `WorldEnvironment` | Node | background_color, ambient_color, ambient_energy |
| `StaticBody3D` | Node3D | collision_layer, collision_mask |
| `RigidBody3D` | Node3D | mass, gravity_scale |
| `CharacterBody3D` | Node3D | velocity, `move_and_slide()` |
| `CollisionShape3D` | Node3D | shape (box/sphere/capsule), size |
| `Area3D` | Node3D | monitoring, signals `body_entered`, `body_exited` |

For physics, delegate to Panda3D's Bullet module inside `engine/drivers/`. Nodes never call Bullet directly.

---

## PHASE 11 — Make it installable software

**11.1 Console entry point**
- In `pyproject.toml`: `[project.scripts] raven = "editor.main:main"`.
- Done when: `pip install -e .` then `raven` opens the home screen.

**11.2 Build the macOS app**
- Use PyInstaller (or Briefcase): produces `Raven.app`.
- Include data files (templates, icons). Test by double-clicking the app on a Mac that does not have your Python environment.
- Known issues to expect: large app size, first-launch warning because the app is not signed or notarised (a paid Apple developer account is needed to remove it).

**11.3 Windows and Linux (later)**
- Same tools, built on those operating systems. Do not promise these until you have tested them.

**11.4 Game export (later, not Version 1)**
- Package `runtime/` + the project's data into a standalone app. Needs its own plan.

---

# TESTING AND QUALITY

- Every step has tests. Core (Phase 1) is plain pytest, no window needed.
- UI tests use `pytest-qt` (create the widget, simulate a click, assert state).
- Before every commit: run all tests; run the app and click through the feature once.
- After each phase, run a "real workflow" check:

| After phase | Manual check |
|---|---|
| 2 | Create, close, reopen a project through code |
| 3 | Create and reopen a project through the UI |
| 4 | Add, rename, delete nodes; edit properties; undo |
| 5 | Cube in viewport; move it; select it by clicking |
| 6 | Blender model imported and visible |
| 7 | Script attached and running |
| 9 | Play/Stop works and errors show in Console |
| 11 | App launches by double-click |

---

# PROMPT TEMPLATE FOR EACH STEP

```
Read RULES.md and the current repo.
Task: <step number and name>.
Goal: <the "What" from this guide>.
Files to create or edit: <list from this guide>.
Dependencies already built: <list>.
Acceptance test: <the "Done when" line>.
Write the code and pytest tests, run them, fix failures,
and report: files created, files modified, test output, known limitations.
Do not do anything outside this task.
```

---

# KNOWN RISKS

1. **Viewport inside Qt on macOS** may not embed cleanly. Fallback: separate viewport window (acceptable for Version 1).
2. **Panda3D + Qt event loops** both want to control the main loop. Test in Phase 0; drive Panda3D manually from a Qt timer if needed.
3. **Python is slower than C++.** Fine for small scenes. Measure before optimising.
4. **Packaged app size and warnings** on macOS (unsigned apps).
5. **AI-generated code you don't understand** is the biggest risk. If you cannot explain a file, ask the AI to explain it before you continue.
6. **Scope creep.** If an idea isn't in this guide, put it in `IDEAS.md` and keep building.

---

# DEFINITION OF DONE — VERSION 1

- [ ] Launch Raven by double-clicking the app
- [ ] Create a project from the home screen; see it in Recent after relaunch
- [ ] Open the editor with Scene tree, Inspector, Viewport, File System, Script editor, Console
- [ ] Add, rename, delete, reparent nodes with undo/redo
- [ ] Edit any node property in the Inspector
- [ ] Import a Blender GLB by drag and drop and place it in the scene
- [ ] Create and attach a Python script, edit it in the script window
- [ ] Change settings in the Settings dialog; they persist
- [ ] Save and reopen the scene
- [ ] Press Play to run the game in its own window; Stop closes it
- [ ] All tests pass
