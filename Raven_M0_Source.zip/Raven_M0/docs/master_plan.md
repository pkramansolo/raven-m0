# RAVEN — MASTER DEVELOPMENT PLAN
## Independent Python-First 3D Game Engine

**Document:** `docs/master_plan.md`  
**Project:** Raven  
**Primary developer:** Solo developer using AI-assisted development  
**Initial development platform:** macOS  
**Initial release target:** MVP-A  
**Future platforms:** Windows first, then other platforms based on feasibility

---

# 1. PROJECT VISION

Build Raven, an independent, Python-first, 3D game engine with a desktop editor.

Raven should provide a structured game-development workflow inspired by the usability and organization of Godot, but it must have its own architecture, implementation, codebase, identity, and interface.

The objective is not to reproduce all of Godot.

The objective is to create a real, usable, installable 3D game engine that can gradually grow into a more capable development platform.

The engine should eventually support:

- Creating and managing game projects.
- Creating 3D scenes.
- Building node hierarchies.
- Editing object properties.
- Creating primitive 3D objects.
- Importing GLB/glTF models.
- Writing Python scripts.
- Running games in a separate runtime window.
- Saving and reopening projects.
- Configuring project and editor settings.
- An integrated AI development assistant.
- Exporting completed games for different platforms.

These capabilities will be introduced in controlled releases. Do not implement all of them immediately.

# 2. DEVELOPER AND DEVELOPMENT ENVIRONMENT

The primary developer is working independently with AI coding assistance.

Known development environment:

- Computer: MacBook Air M4.
- Memory: 16 GB RAM.
- Initial operating system: macOS.
- Python environment: Conda environment named `sparrow`.
- Main language: Python.
- Editor: VS Code or another compatible development environment.
- Source control: Git and GitHub.

Do not assume that Windows hardware is available to the developer.

Before executing commands, inspect the available development tools and explain what can actually be executed.

If you do not have terminal, repository, or file-system access in the current environment, do not pretend that files were created, commands were executed, or tests passed. Provide the exact files or commands the developer needs to use.

Optimize development tools and dependencies for a 16 GB Mac.

Avoid unnecessarily large models, services, and background processes.

# 3. DEVELOPMENT PRINCIPLES

Follow these principles throughout the project:

1. Build working software, not disconnected code samples.
2. Keep one authoritative architecture.
3. Keep the folder structure organized.
4. Give every file a clearly defined responsibility.
5. Avoid duplicate classes and systems.
6. Maintain consistent interfaces between modules.
7. Write tests for important functionality.
8. Never claim untested work is complete.
9. Never silently change the architecture or dependencies.
10. Explain significant technical decisions.
11. Prioritize stability over feature quantity.
12. Document limitations honestly.
13. Keep the project understandable to a solo developer.
14. Implement one milestone at a time.
15. Wait for approval before moving to the next major milestone.

For every major task, identify:

- What needs to be built.
- Which files need to be created.
- Which files need to be modified.
- How the modules connect.
- What dependencies are required.
- What could fail.
- How the implementation will be tested.

# 4. RELEASE STRATEGY — THREE STAGES

Do not treat every planned feature as part of the first MVP.

## MVP-A — macOS Engine and Editor

This is the first release and the immediate development priority.

Target: MacBook Air M4, 16 GB RAM.

Deliver a working macOS application that can:

- Launch as a desktop application.
- Create a Raven project.
- Open an existing Raven project.
- Display a node-based scene hierarchy.
- Add and configure the initial seven node types.
- Render a 3D scene.
- Create primitive meshes.
- Import GLB/glTF models.
- Edit node properties.
- Save and reopen scenes.
- Edit and attach basic Python scripts.
- Run a game in a separate runtime window.
- Stop a running game.
- Display useful errors and logs.
- Save project settings and editor preferences.

MVP-A must produce:

- A working macOS application bundle.
- A downloadable `.dmg` installer.
- Installation documentation.
- A sample project.

**Do not include the AI assistant or full game exporting in MVP-A.**

## MVP-B — Windows Support

After MVP-A is stable, add Windows support.

Requirements:

- Windows-compatible application startup.
- Windows file dialogs.
- Windows path handling.
- Windows-specific runtime launching.
- Windows packaging.
- Dependency compatibility.
- Windows application icon and metadata.
- Windows installer.
- Windows portable build.

Use GitHub Actions with Windows runners to build and test the application.

The AI must not claim Windows compatibility simply because the code looks cross-platform.

Verification rules:

1. CI must successfully build the Windows application.
2. Automated tests must pass on the Windows runner.
3. The packaged application must be manually tested on a real Windows machine before Windows support is described as fully verified.
4. If no real Windows machine is available, report the status as **CI-built, not manually verified**.
5. Clearly document remaining platform risks.

Expected distribution:

- `Raven-Setup.exe`
- `Raven-Portable.zip`

## LATER RELEASES

Introduce these only after MVP-A is stable and MVP-B has a clear verification status.

### Later Release 1 — Integrated AI Assistant

Add an assistant inside the Raven editor.

### Later Release 2 — Game Export System

Allow developers to export games created in Raven into distributable builds.

### Later Release 3 — Additional Engine Features

Potential features:

- Physics.
- Collision.
- Animation.
- Navigation.
- Audio.
- Particles.
- Additional rendering features.
- Linux support.
- Android support.
- Web support.

Do not claim these features exist until implemented and tested.

# 5. TECHNOLOGY STACK

Use this stack unless M0 demonstrates a concrete reason to change it.

| Area | Technology |
|---|---|
| Programming language | Python 3.11 or 3.12 |
| Desktop interface | PySide6 |
| 3D rendering | Panda3D |
| GLB/glTF support | panda3d-gltf |
| Numerical operations | NumPy |
| User directories | platformdirs |
| Unit testing | pytest |
| UI testing | pytest-qt |
| Application packaging | PyInstaller |
| macOS DMG creation | create-dmg or an equivalent verified tool |
| Windows installer | Inno Setup or NSIS |
| Version control | Git and GitHub |
| Documentation | Markdown |
| CI | GitHub Actions |

## Dependency management

Use `pyproject.toml` as the single authoritative dependency and project configuration file.

Do not maintain a second independent list of dependency versions in `requirements.txt`.

If a requirements file is needed for deployment, generate or derive it from the authoritative configuration.

Pin compatible dependency versions.

Before the packaging milestone, create a dependency and license inventory containing:

- Dependency name.
- Version.
- License.
- Purpose.
- Distribution implications.
- Required notices or attribution.
- Known packaging limitations.

Pay particular attention to PySide6 licensing and distribution obligations. Do not assume that using a package in development automatically satisfies the conditions for distributing a bundled application.

# 6. RENDERING ARCHITECTURE

Raven must separate the engine from its rendering implementation.

Only this module may directly import and manage Panda3D:

`src/raven/engine/drivers/panda_driver.py`

The `panda3d-gltf` integration must also remain inside the driver layer because it interacts with Panda3D.

Do not expose Panda3D objects directly to:

- Scene nodes.
- Editor UI.
- Python scripts.
- Project management.
- Scene serialization.
- General engine systems.

Use a rendering interface between the engine and the driver.

The purpose is to prevent the entire engine from depending on one rendering backend.

## M0 integration experiment

Before implementing the engine, prove the following:

1. Create a PySide6 desktop window.
2. Create an actual Panda3D rendering view.
3. Display a 3D primitive.
4. Test viewport resizing.
5. Test camera movement.
6. Test keyboard and mouse input.
7. Test application shutdown.
8. Check resource cleanup.
9. Check whether the viewport can be embedded reliably.
10. Document the result.

Attempt embedding first.

If embedding is unstable, use a separate viewport window as a deliberate fallback.

Do not proceed to the full engine until the integration approach has been tested and documented.

# 7. COORDINATE SYSTEM

Establish one consistent internal coordinate convention.

Recommended convention:

- Right-handed coordinate system.
- Y-up.
- -Z forward.
- Radians for angles.
- Quaternion-based orientation where appropriate.

Panda3D has its own coordinate conventions and configuration options. Confirm the actual rendering configuration during M0.

All conversion between Raven's internal coordinate representation and Panda3D must happen inside the driver.

Document the convention in:

`docs/architecture/coordinate_system.md`

# 8. RECOMMENDED FOLDER STRUCTURE

Use the following structure as the initial architecture.

Do not create every file as an empty placeholder. Create each file when its implementation is required.

```text
Raven/
│
├── README.md
├── RULES.md
├── pyproject.toml
├── .gitignore
├── .env.example
│
├── docs/
│   ├── master_plan.md
│   │
│   ├── architecture/
│   │   ├── overview.md
│   │   ├── folder_structure.md
│   │   ├── module_dependencies.md
│   │   ├── class_registry.md
│   │   ├── coordinate_system.md
│   │   └── decisions.md
│   │
│   ├── development/
│   │   ├── roadmap.md
│   │   ├── progress.md
│   │   ├── testing.md
│   │   └── known_limitations.md
│   │
│   ├── user_guide/
│   └── release/
│
├── src/
│   └── raven/
│       ├── __init__.py
│       ├── main.py
│       │
│       ├── engine/
│       │   ├── core/
│       │   │   ├── object.py
│       │   │   ├── node.py
│       │   │   ├── node3d.py
│       │   │   ├── scene_tree.py
│       │   │   ├── lifecycle.py
│       │   │   ├── signals.py
│       │   │   ├── registry.py
│       │   │   └── properties.py
│       │   │
│       │   ├── math/
│       │   │   ├── vector3.py
│       │   │   ├── quaternion.py
│       │   │   └── transform3d.py
│       │   │
│       │   ├── nodes/
│       │   │   ├── mesh_instance_3d.py
│       │   │   ├── camera_3d.py
│       │   │   ├── directional_light_3d.py
│       │   │   ├── omni_light_3d.py
│       │   │   └── world_environment.py
│       │   │
│       │   ├── scene/
│       │   │   ├── scene.py
│       │   │   ├── schema.py
│       │   │   ├── serializer.py
│       │   │   ├── deserializer.py
│       │   │   └── validator.py
│       │   │
│       │   ├── resources/
│       │   │   ├── resource.py
│       │   │   ├── mesh_resource.py
│       │   │   ├── material_resource.py
│       │   │   ├── texture_resource.py
│       │   │   └── resource_cache.py
│       │   │
│       │   ├── rendering/
│       │   │   ├── render_interface.py
│       │   │   └── render_types.py
│       │   │
│       │   ├── drivers/
│       │   │   └── panda_driver.py
│       │   │
│       │   ├── project/
│       │   │   ├── project.py
│       │   │   ├── project_manager.py
│       │   │   ├── project_config.py
│       │   │   └── path_manager.py
│       │   │
│       │   └── settings/
│       │       ├── settings_registry.py
│       │       └── project_settings.py
│       │
│       ├── editor/
│       │   ├── main_window.py
│       │   ├── home/
│       │   ├── scene_tree/
│       │   ├── inspector/
│       │   ├── viewport/
│       │   ├── filesystem/
│       │   ├── script_editor/
│       │   ├── console/
│       │   ├── dialogs/
│       │   └── settings/
│       │
│       ├── runtime/
│       │   ├── runtime_context.py
│       │   ├── runtime_launcher.py
│       │   └── game_process.py
│       │
│       └── scripting/
│           ├── script_resource.py
│           ├── script_loader.py
│           └── script_api.py
│
├── tests/
│   ├── unit/
│   ├── integration/
│   ├── ui/
│   ├── packaging/
│   └── fixtures/
│
├── scripts/
│   ├── m0_qt_panda_smoke_test.py
│   ├── build_macos.py
│   ├── build_windows.py
│   └── verify_release.py
│
├── assets/
│   ├── icons/
│   └── default_resources/
│
└── .github/
    └── workflows/
        ├── tests.yml
        └── windows-build.yml
```

Platform-specific modules should be introduced only when needed.

The folder structure must remain consistent with actual implementation.

# 9. CORE ENGINE SYSTEM

Build a node-based scene architecture.

Initial core classes:

- Object
- Node
- Node3D
- SceneTree
- Lifecycle
- Signals
- Property definitions
- Node registry

Requirements:

- Unique object identity.
- Node names.
- Parent-child relationships.
- Adding and removing children.
- Reparenting.
- Node lookup.
- Scene traversal.
- Lifecycle handling.
- Property validation.
- Signal connection and disconnection.
- Node factory and registration.

Define ownership and lifecycle rules before implementation.

# 10. MATH AND TRANSFORM SYSTEM

Implement:

- Vector3.
- Quaternion.
- Transform3D.
- Local transforms.
- Global transforms.
- Parent transform inheritance.
- Position.
- Rotation.
- Scale.

Test transform calculations independently of Panda3D.

Avoid mixing rendering-specific transform objects with Raven's internal math system.

# 11. INITIAL NODE TYPES

Keep the first release limited to seven node types:

1. Node
2. Node3D
3. MeshInstance3D
4. Camera3D
5. DirectionalLight3D
6. OmniLight3D
7. WorldEnvironment

Primitive geometry:

- Box.
- Sphere.
- Cylinder.
- Plane.

Deferred nodes:

- StaticBody3D.
- RigidBody3D.
- CharacterBody3D.
- CollisionShape3D.
- Area3D.
- RayCast3D.
- ShapeCast3D.
- NavigationAgent3D.
- AnimationPlayer.
- AnimationTree.
- GPUParticles3D.

Do not increase the initial node list without a clear technical and product reason.

# 12. RESOURCE AND SCENE SYSTEM

Implement:

- Base resource.
- Mesh resources.
- Material resources.
- Texture resources.
- Resource references.
- Resource cache.
- Resource loading.
- Resource validation.
- Resource ownership.
- GLB/glTF model import.

Use project-relative asset paths wherever possible.

## Scene format

Use versioned JSON-based scene files.

Project configuration:

`project.raven`

Scene example:

`scenes/main.scene.json`

Do not use `.raven` for both the project file and scene files.

Scene requirements:

- Save.
- Load.
- Restore hierarchy.
- Restore supported properties.
- Restore resource references.
- Validate malformed files.
- Handle unknown node types.
- Report missing resources.
- Preserve supported metadata.
- Provide migration support for future schema changes.

Use atomic file saving.

Never silently discard unsupported scene data.

# 13. PROJECT MANAGEMENT

A typical Raven project should look like this:

```text
MyGame/
├── project.raven
├── scenes/
│   └── main.scene.json
├── scripts/
│   └── player.py
├── assets/
│   ├── models/
│   ├── textures/
│   └── materials/
├── resources/
└── .raven/
    └── cache/
```

Implement:

- New project.
- Open project.
- Close project.
- Recent projects.
- Project configuration.
- Main scene.
- Project-relative paths.
- Save and reopen.
- Missing asset reporting.
- Project version metadata.

Ensure that resolving a project-relative resource cannot escape the intended project directory.

Important security rule:

Python scripts are executable code. Path validation does not sandbox Python. Warn users before running untrusted project scripts.

# 14. EDITOR INTERFACE

The editor should be a coherent desktop application.

## Home screen

- New Project.
- Open Project.
- Recent Projects.
- Project location.
- Raven version.

## Main editor

### Scene Tree

- Show hierarchy.
- Add nodes.
- Delete nodes.
- Rename nodes.
- Reparent nodes.
- Select nodes.

### Inspector

- Display selected node properties.
- Edit supported properties.
- Position.
- Rotation.
- Scale.
- Mesh references.
- Material references.
- Camera properties.
- Light properties.

### 3D Viewport

- Render the active scene.
- Display primitive geometry.
- Camera navigation.
- Object selection where implemented.
- Grid.
- Snapping.
- Resize handling.
- Rendering error display.

### File System

- Browse project files.
- Create directories.
- Import GLB/glTF models.
- Show missing files.

### Script Editor

- Open scripts.
- Edit scripts.
- Save scripts.
- Attach scripts to compatible nodes.
- Show syntax errors.

### Console

- Engine logs.
- Python errors.
- Runtime logs.
- Clear error information.

### Toolbar

- Save.
- Undo.
- Redo.
- Add Node.
- Play.
- Stop.
- Project Settings.
- Editor Preferences.

Use Qt's undo/redo infrastructure where appropriate.

# 15. PYTHON SCRIPTING

Python is Raven's initial game scripting language.

Implement a clear script attachment and execution model.

Initial lifecycle:

- `_ready()`
- `_process(delta)`

Initial API goals:

- Access nodes.
- Change transforms.
- Read properties.
- Input actions.
- Signals.
- Console output.

Before finalizing the API, define:

- Whether scripts inherit from node classes or attach as behaviors.
- How scripts are instantiated.
- Which node types accept which scripts.
- How lifecycle methods are called.
- How script instances are destroyed.
- How script errors are reported.

Do not create an ambiguous script inheritance system.

Python is not sandboxed by default. Document this limitation and warn users about untrusted scripts.

# 16. RUNTIME AND PLAY/STOP

The runtime should be separate from the editor.

When Play is clicked:

1. Validate the project.
2. Identify the selected main scene.
3. Launch the runtime.
4. Load the scene.
5. Initialize the runtime.
6. Execute attached scripts.
7. Render the game.
8. Process input and updates.

When Stop is clicked:

1. Stop the game.
2. Shut down the runtime.
3. Release resources.
4. Close the runtime window.
5. Return control to the editor.

## Packaged runtime launching

Do not depend on `python -m runtime.run_game` after packaging.

In development mode, use a suitable Python module or process launcher.

In the packaged application, launch the bundled Raven executable again using a dedicated runtime mode, for example:

`Raven --runtime <project-path> --scene <scene-path>`

The executable must distinguish editor startup from runtime startup.

The exact argument and process design must be documented and tested.

Do not claim runtime packaging works until it has been tested from the actual packaged application.

# 17. SETTINGS SYSTEM

Separate project settings from editor preferences.

## Project settings

- Application name.
- Main scene.
- Window width.
- Window height.
- Fullscreen.
- VSync.
- Shadows enabled.
- Physics tick rate.
- Input actions.

## Editor preferences

- Theme.
- Interface font size.
- Viewport camera speed.
- Grid visibility.
- Snap enabled.
- Snap step.
- Code editor font size.
- Code indentation size.

Use typed definitions, defaults, validation, and persistence.

Do not duplicate setting definitions across modules.

# 18. MVP-A MILESTONES

Build in this order.

## M0 — Technical Risk Spike

Prove PySide6 and Panda3D integration.

Deliver:

- Working desktop window.
- Working 3D view.
- Resize handling.
- Input test.
- Camera test.
- Clean shutdown.
- Written integration decision.
- Test report.

Do not proceed if the rendering architecture is not proven.

## M1 — Engine Foundation

Implement:

- Core objects.
- Nodes.
- Node3D.
- Math.
- SceneTree.
- Lifecycle.
- Signals.
- Properties.
- Node registry.
- Seven initial node types.
- Resource foundation.
- Rendering interface.
- Panda3D driver.

## M2 — Project and Scene Persistence

Implement:

- Project manager.
- Project configuration.
- Path manager.
- Scene schema.
- Serialization.
- Deserialization.
- Validation.
- Resource references.
- Automated tests.

## M3 — Home Screen

Implement:

- New Project.
- Open Project.
- Recent Projects.
- Project location.
- Project validation.

## M4 — Editor Shell

Implement:

- Main editor window.
- Scene Tree.
- Inspector.
- Toolbar.
- Dock layout.
- Undo/redo foundation.

## M5 — 3D Viewport

Implement:

- Scene rendering.
- Primitive meshes.
- Camera controls.
- Viewport resizing.
- Selection where feasible.
- Grid and snapping foundations.

## M6 — Asset Import

Implement:

- File browser.
- GLB/glTF import.
- Resource references.
- Import errors.
- Missing asset reporting.

## M7 — Python Scripting

Implement:

- Script editor.
- Script loader.
- Script attachment.
- Lifecycle.
- Script API.
- Error reporting.

## M8 — Play/Stop

Implement:

- Runtime launcher.
- Separate runtime process.
- Game window.
- Input handling.
- Script execution.
- Stop and cleanup.

## M9 — Settings and Stabilization

Implement:

- Project settings.
- Editor preferences.
- Persistence.
- Integration tests.
- Bug fixing.
- Performance checks.
- Documentation.

## M10 — macOS Packaging

Implement:

- PyInstaller packaging.
- Application metadata.
- Application icon.
- `.app` generation.
- DMG creation.
- Dependency license inventory.
- Clean-machine installation procedure.
- Packaged runtime verification.

## M11 — MVP-A Release

Deliver:

- Tested macOS application.
- Downloadable DMG.
- Sample project.
- User guide.
- Installation instructions.
- Release notes.
- Known limitations.
- GitHub Release.

MVP-A is not complete merely because the source code works in the development environment.

# 19. MVP-B WINDOWS ROADMAP

Only start this after MVP-A is stable.

Implement:

- Windows platform abstraction.
- Windows path handling.
- Windows runtime launch.
- Windows packaging.
- Windows installer.
- Portable build.
- Windows-specific testing.
- GitHub Actions Windows build.

Use Windows CI for automated verification.

Require a real Windows machine for final manual verification.

If manual verification has not happened, state that Windows is not fully verified.

# 20. GITHUB AND SOURCE CONTROL

Use one authoritative GitHub repository.

Recommended:

- Private repository during early development.
- Stable main branch.
- Feature branches for substantial changes.
- Commits after verified milestones.
- Descriptive commit messages.
- Architecture documentation in the repository.
- GitHub Releases for downloadable binaries.

Use a `.gitignore` covering:

- `__pycache__/`
- `*.py[cod]`
- `.venv/`
- `venv/`
- `.env`
- `.env.*`
- `.DS_Store`
- `build/`
- `dist/`
- `.pytest_cache/`
- `.coverage`
- `htmlcov/`
- Local project files and private data.

Never commit:

- API keys.
- Passwords.
- Tokens.
- Private keys.
- Client data.
- Personal credentials.
- Local environment files containing secrets.

Use `.env.example` to document required environment variables without including real credentials.

Enable appropriate GitHub security features, including two-factor authentication and secret protection where available.

# 21. AI ASSISTANT — LATER RELEASE

Do not implement the AI assistant in MVP-A.

The intended design is a floating assistant inside the Raven editor.

Visual direction:

- Compact floating window.
- Movable.
- Modern dark interface.
- Circular visualizer or avatar area.
- Chat and Voice modes.
- Clean desktop application styling.

## Chat mode

- Message history.
- Text input.
- Send.
- Responses.
- Loading state.
- Error handling.

## Voice mode

- Microphone interaction.
- Speech input.
- Recording state.
- Stop recording.
- Voice output if supported.

## Backend requirement

Do not assume an existing chatbot backend is available.

Before implementation, inspect the actual chatbot code or ask the developer for:

- Backend source code.
- API/interface description.
- Required dependencies.
- Authentication requirements.
- Local or cloud execution model.
- Voice capabilities.
- Data handling and privacy requirements.

If the backend is unavailable, create a documented adapter interface and a mock implementation for UI testing.

Do not invent an integration.

## Project context

The assistant may use relevant information about:

- Current project.
- Active scene.
- Node tree.
- Selected node.
- Selected properties.
- Relevant scripts.
- Runtime errors.

Do not transmit the entire project unnecessarily.

If using a cloud backend, clearly explain what project data is sent externally.

If using a local model, consider the 16 GB system memory limit and the resources consumed by Panda3D and the editor.

When a project closes, clear its active assistant context.

Never allow destructive scene changes without user confirmation.

# 22. GAME EXPORT SYSTEM — LATER RELEASE

Game exporting is a separate system from packaging Raven itself.

Do not include full game exporting in MVP-A.

Eventually, developers should be able to select Export Project and create downloadable games.

## Intended export targets

First priority:

- macOS.
- Windows.

Future possibilities:

- Linux.
- Android.
- Web.

These future targets require independent runtime and packaging feasibility tests.

## Export interface

- Target platform.
- Build architecture.
- Output directory.
- Game name.
- Application icon.
- Main scene.
- Export preset.
- Build mode.
- Export button.
- Build progress.
- Build logs.
- Error report.
- Open output folder.

## Export architecture

Proposed package:

`src/raven/export/`

Potential modules:

- export_manager.py
- export_preset.py
- export_profile.py
- export_validator.py
- resource_collector.py
- script_packager.py
- runtime_packager.py
- platform_exporter.py
- build_pipeline.py
- build_report.py

## Export requirements

- Exported games must not require Raven to be installed.
- Exported games must not require a separately installed Python interpreter.
- Include required runtime components.
- Include necessary assets and scripts.
- Exclude editor-only files.
- Validate resource references.
- Report unsupported features.
- Test exported builds independently from the editor.

Do not claim a target platform is supported until an exported game has been built and tested on that platform.

# 23. DOCUMENTATION AND CODE QUALITY

Every Python source file must include:

- Module docstring.
- Class docstrings.
- Public method docstrings.
- Type hints.
- Parameter and return descriptions where appropriate.
- Meaningful comments for non-obvious logic.
- Clear exception handling.

Avoid comments that simply repeat what a line of code already says.

Maintain:

- Architecture overview.
- Folder structure.
- Module dependency map.
- Class registry.
- Coordinate system.
- API documentation.
- Development progress.
- Testing documentation.
- Known limitations.
- Installation guide.
- User guide.

# 24. TESTING AND RELEASE QUALITY

Create:

- Unit tests.
- Integration tests.
- UI tests.
- Packaging tests.

Test:

- Node hierarchy.
- Transform calculations.
- Lifecycle.
- Signals.
- Properties.
- Node registration.
- Resource loading.
- Scene serialization.
- Project creation.
- Project opening.
- Project saving.
- Path validation.
- Rendering integration.
- Script execution.
- Runtime start and stop.
- Settings persistence.
- Application shutdown.
- Packaged runtime launching.

A passing unit test does not prove the whole application works.

A successful macOS build does not prove Windows compatibility.

A successful CI build does not replace final manual testing of a packaged application.

Maintain a visible list of:

- Verified functionality.
- Partially implemented functionality.
- Untested functionality.
- Known bugs.
- Deferred features.

# 25. ACCEPTANCE CRITERIA

## MVP-A acceptance

MVP-A is complete only when:

1. Raven launches on macOS.
2. The application can be installed from a DMG.
3. The application runs without requiring a separate Python installation.
4. A user can create a project.
5. A user can open an existing project.
6. A user can save and reopen projects.
7. The Scene Tree works.
8. The seven initial node types can be created and configured.
9. The viewport renders a scene.
10. Primitive meshes work.
11. GLB/glTF import works.
12. The Inspector edits supported properties.
13. Scenes can be saved and loaded.
14. Python scripts can be edited and attached.
15. Play and Stop work.
16. Runtime errors are reported.
17. Settings persist.
18. The packaged application is tested.
19. Documentation is available.
20. A downloadable macOS release exists.

The AI assistant, Windows support, and game exporting are not MVP-A acceptance requirements.

## MVP-B acceptance

MVP-B is complete only when:

1. Windows builds successfully in CI.
2. Windows automated tests pass.
3. The installer works.
4. The portable build works.
5. The packaged runtime launches.
6. A real Windows machine has been used for manual testing.

If the final condition is missing, label the release as not manually verified.

# 26. AI CODING WORKFLOW

Before starting any task:

1. Inspect the current repository.
2. Read `RULES.md`.
3. Read `docs/master_plan.md`.
4. Read the latest progress report.
5. Check existing classes and interfaces.
6. Identify dependencies.
7. List files to create or modify.
8. Explain the implementation.
9. Identify risks.
10. Define acceptance tests.

During implementation:

- Work on one logical task at a time.
- Do not regenerate working files unnecessarily.
- Preserve established interfaces.
- Use correct folders.
- Keep dependencies consistent.
- Add comments and docstrings.
- Run tests.
- Update documentation.

After implementation, report:

1. Files created.
2. Files modified.
3. Functionality implemented.
4. Dependencies added or changed.
5. Commands executed.
6. Tests passed.
7. Tests failed.
8. Manual checks required.
9. Known limitations.
10. Risks.
11. Recommended next task.

Never claim tests passed if they were not executed.

Never claim a platform was verified if it was not tested.

If an implementation fails, explain the reason and provide a corrective plan.

# 27. FIRST TASK — ARCHITECTURE REVIEW ONLY

Do not generate the complete engine.

First inspect the available repository and development environment.

If no repository exists, propose the initial setup.

Your first response must contain:

1. Understanding of Raven.
2. Professional architecture assessment.
3. Feasibility of Python, PySide6, and Panda3D.
4. M0 technical integration experiment.
5. Initial dependency list.
6. Recommended folder structure.
7. Module dependency map.
8. Part 1 implementation plan.
9. macOS packaging strategy.
10. Windows future compatibility strategy.
11. Testing strategy.
12. Resource and memory risks.
13. Dependency license considerations.
14. Missing architectural decisions.
15. Risks and solutions.

Do not implement the entire engine.

Wait for my approval.

After approval, begin with M0 only.

---

# FINAL DEVELOPMENT PRINCIPLE

Raven is a long-term independent game-engine project.

The first priority is not to compete with Godot feature-for-feature.

The first priority is to build a reliable, working, installable macOS 3D editor and engine.

Then expand carefully into Windows support, AI assistance, and game exporting.

Always prioritize:

**Working software > architecture consistency > testing > stability > new features.**