# M0 integration decision — pending macOS verification

- Qt desktop shell: implemented; must be launched on macOS.
- Panda3D standalone viewport: implemented; must be launched on macOS.
- Qt/Panda embedded viewport: **not yet attempted or validated**. This is a required remaining M0 experiment.
- Separate-window process fallback: implemented, but not yet manually verified.
- Rendering coordinates: Panda3D default Z-up for this spike. Raven's proposed Y-up/-Z-forward convention requires explicit driver conversion in M1.

**Gate:** Do not choose an embedded or separate viewport as the permanent architecture until Mac tests document resize, camera, input, shutdown, and cleanup.
