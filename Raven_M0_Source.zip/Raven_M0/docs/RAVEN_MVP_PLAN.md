# RAVEN MVP — Master Plan for the AI Developer

> Give this entire file to the AI at the start of every session.
> Then give it ONE milestone task at a time (see section 11).

---

## 1. Mission

Build **Raven MVP**: an installable desktop application where a developer can:

1. Open Raven and see a home screen with recent projects.
2. Create a new 3D project, and reopen it later.
3. Add 3D nodes to a scene, rename, delete and reorder them, with undo and redo.
4. Edit each node's properties in an Inspector panel.
5. Import a Blender model (GLB) by drag and drop and place it in the scene.
6. Write and attach a Python script to a node, using a built-in script editor.
7. Press **Play** to run the game in its own window, and **Stop** to end it.
8. Save the scene and project, close Raven, and reopen everything exactly as it was.
9. Install Raven as a normal application (macOS `.app` first).

Raven is a **3D-only**, **Python-first**, Godot-inspired engine. It is an independent project: do not copy Godot source code; copy only the *ideas* (node tree, scenes, signals, lifecycle callbacks, Inspector).

**The MVP is finished when the demo project in section 12 can be built and played using only the installed app.**

---

## 2. Non-goals (do NOT build these in the MVP)

- Any 2D nodes or 2D editor view
- Asset library / store
- Animation, audio, navigation, particles, CSG, GridMap
- Debugger with breakpoints, hot reload, plugin system
- Mesh modelling inside Raven (Blender does that; Raven imports GLB)
- Standalone game export (only the editor is packaged in the MVP)
- Windows/Linux packages (keep code portable, but only macOS is tested)
- Multiplayer, networking, cloud

If an idea is not in this file, write it into `IDEAS.md` and continue.

---

## 3. Technology decisions

| Need | Choice | Notes |
|---|---|---|
| Language | Python 3.11 or 3.12 | The environment is named `sparrow` |
| Editor UI | PySide6 | Docks, trees, dialogs, text editor |
| 3D rendering | Panda3D + `panda3d-gltf` | Renderer wrapped behind a driver layer |
| Maths | NumPy | |
| Config folders | `platformdirs` | |
| Tests | pytest, pytest-qt | |
| Packaging | PyInstaller (Briefcase if PyInstaller fails) | |
| Other languages | **None** unless a measured problem cannot be solved in Python | Report the measurement before proposing it |

**Hard rule:** only `engine/drivers/panda_driver.py` may import Panda3D. Nodes and scripts never see Panda3D objects, so the renderer can be replaced later.

---

## 4. Machine and environment

- Target machine: MacBook Air M4, 16 GB RAM, macOS. The same machine also runs local AI models, so keep memory use modest.
- Use the existing Python environment `sparrow`.
- Add dependencies only when a step needs them, and list each in `pyproject.toml` with the reason.

---

## 5. Architecture

Three layers, strictly separated:

```
EDITOR  (PySide6)        -> imports engine, project, settings
RUNTIME (run_game.py)    -> imports engine, project, settings   (never the editor)
ENGINE  (nodes, scene tree, scripting, drivers)  -> imports nothing from editor/runtime
```

Folder structure:

```
raven/
├── pyproject.toml   README.md   RULES.md   IDEAS.md   raven_launcher.py
├── engine/
│   ├── core/        property.py signal.py object.py node.py scene_tree.py
│   │                node_registry.py scene_io.py transform.py logging.py
│   ├── nodes/       node3d.py mesh_instance_3d.py camera_3d.py
│   │                directional_light_3d.py omni_light_3d.py world_environment.py
│   ├── drivers/     panda_driver.py
│   ├── assets/      import_pipeline.py model_importer.py texture_importer.py
│   └── scripting/   script_loader.py script_api.py input.py
├── settings/        registry.py project_settings.py editor_preferences.py
├── project/         project_file.py project_manager.py templates/empty_3d/
├── editor/
│   ├── main.py home_screen.py main_window.py undo.py
│   ├── panels/      scene_tree_panel.py inspector_panel.py viewport_panel.py
│   │                file_system_panel.py script_editor_panel.py console_panel.py
│   └── dialogs/     new_project_dialog.py add_node_dialog.py settings_dialog.py
├── runtime/         run_game.py
├── tests/           examples/mvp_demo/   documentation/
```

One node = one file. Shared behaviour lives in base classes (`Object`, `Node`, `Node3D`).

---

## 6. Data formats

### Project folder
```
MyGame/
├── project.raven
├── scenes/main.scene.json
├── scripts/
├── assets/models/  assets/textures/
└── .raven/            (cache and import data; Git-ignored)
```

### project.raven
```json
{
  "raven_format": 1,
  "name": "MyGame",
  "main_scene": "scenes/main.scene.json",
  "settings": { "display/window/width": 1280, "display/window/height": 720 }
}
```

### Scene file
```json
{
  "raven_format": 1,
  "root": {
    "type": "Node3D", "name": "Main", "properties": {},
    "children": [
      {"type": "Camera3D", "name": "Camera",
       "properties": {"position": [0, 2, 6], "fov": 70}, "children": []},
      {"type": "MeshInstance3D", "name": "Robot",
       "properties": {"mesh_path": "assets/models/robot.glb",
                      "script": "scripts/robot.py"}, "children": []}
    ]
  }
}
```

Rules:
- All paths inside a project are **relative** to the project folder.
- Only properties that differ from defaults are saved.
- Files are written to a temporary file then renamed, so a crash cannot corrupt a project.
- A project may only read and write inside its own folder (reject `..` and links that leave the folder).
- Unknown node types or properties on load: log a warning, keep loading, never crash.

---

## 7. Core design decisions (do not change without writing a decision note)

**Property system.** Each node class declares properties with: name, type, default, validation (min/max/choices), category, editor hint. The Inspector builds itself from this list. Supported types: bool, int, float, str, Vector3, Color, enum, file path.

**Lifecycle.** The engine calls `_enter_tree`, `_ready`, `_process(delta)`, `_physics_process(delta)`, `_exit_tree`. Nodes and scripts never call these manually. `_physics_process` runs at a fixed rate from project settings (default 60).

**Signals.** `Signal.connect / disconnect / emit`. A failing listener is logged and does not stop the others.

**Undo/redo.** Every editor change to scene data goes through a `QUndoStack` command: `SetProperty`, `AddNode`, `DeleteNode`, `RenameNode`, `ReparentNode`. No exceptions.

**Play = separate process.** The editor saves, then starts `python -m runtime.run_game <project>`, reads its output into the Console, and Stop terminates it. A crashing game cannot crash the editor.

**Viewport.** Decided in Milestone 0. If embedding Panda3D in a Qt panel is unreliable on macOS, use a separate viewport window for the MVP and record this in `documentation/decisions.md`.

**Scripts.** A script is a Python file containing a class that extends the node's type. The engine loads it with `importlib`, binds it to the node, and catches all exceptions (logged with file and line). Scripts are NOT sandboxed and the app must say so when opening projects from outside the user's own folders.

---

## 8. Node set for the MVP

| Node | Parent | Properties | Notes |
|---|---|---|---|
| `Node` | Object | name, script | Base of everything |
| `Node3D` | Node | position, rotation, scale, visible | Global transform, `look_at`, `translate`, `rotate_y` |
| `MeshInstance3D` | Node3D | mesh_path (GLB or primitive: Box/Sphere/Cylinder/Plane), cast_shadow, material_color | Delegates drawing to the driver |
| `Camera3D` | Node3D | fov, near, far, projection, current | |
| `DirectionalLight3D` | Node3D | color, energy, shadow_enabled | |
| `OmniLight3D` | Node3D | color, energy, range | |
| `WorldEnvironment` | Node | background_color, ambient_color, ambient_energy | |

Physics nodes (`StaticBody3D`, `RigidBody3D`, `CharacterBody3D`, `CollisionShape3D`, `Area3D`) come **after** the MVP.

---

## 9. Script API (public, documented in `documentation/script_api.md`)

```python
from raven import Node3D, Input

class Robot(Node3D):
    speed = 3.0

    def _ready(self):
        print("Robot ready")

    def _process(self, delta):
        x = Input.get_axis("move_left", "move_right")
        z = Input.get_axis("move_forward", "move_back")
        self.translate(x * self.speed * delta, 0, z * self.speed * delta)
```

Available to scripts: `Node`, `Node3D`, `MeshInstance3D`, `Camera3D`, `Signal`, `Input` (`is_key_pressed`, `get_axis`, `get_mouse_delta`), `print`. Node methods: `get_node(path)`, `get_parent()`, `add_child()`, `queue_free()`, `get(name)`, `set(name, value)`.

Default input actions: `move_left` (A), `move_right` (D), `move_forward` (W), `move_back` (S).

---

## 10. Settings (minimal, all real)

A setting exists only if something reads it. Settings live in a **registry** (id, type, default, validation, category, description). Project settings and editor preferences are separate stores.

Project settings: `application/name`, `application/main_scene`, `display/window/width`, `display/window/height`, `display/window/fullscreen`, `display/vsync`, `rendering/shadows_enabled`, `physics/tick_rate`, `input/actions`.

Editor preferences: `interface/theme` (dark/light), `interface/font_size`, `viewport/camera_speed`, `viewport/grid_visible`, `viewport/snap_enabled`, `viewport/snap_step`, `code/font_size`, `code/indent_size`.

The Settings dialog is generated from the registry. Invalid values show an inline error; a corrupt settings file falls back to defaults.

---

## 11. Milestones (do them in order; do not start the next until acceptance passes)

### M0 — Prove the risky parts
- 0.1 Install dependencies in `sparrow`; confirm imports work.
- 0.2 Qt window with side docks.
- 0.3 Panda3D window showing a GLB.
- 0.4 Try embedding the Panda3D view in a Qt panel (native window handle, or offscreen-render to an image). Record the winner or the fallback in `documentation/decisions.md`.
- **Accept:** each spike runs on the M4; decision file written.

### M1 — Engine core (no graphics)
- 1.1 Repo, `pyproject.toml`, `RULES.md`, pytest, `.gitignore`, first commit.
- 1.2 Property system.
- 1.3 Signal.
- 1.4 Object base class.
- 1.5 Node (children, unique names, paths, `queue_free`).
- 1.6 SceneTree and loop (ordered `_ready`, `_process`, fixed `_physics_process`).
- 1.7 Transform maths (NumPy).
- 1.8 Node3D (local and global transforms).
- 1.9 Node registry.
- 1.10 Scene save/load round trip.
- 1.11 Settings registry and stores.
- **Accept:** all tests pass; a round-trip test reproduces an identical tree; corrupt JSON gives a clear error.

### M2 — Projects
- 2.1 Project file read/write/validate.
- 2.2 Create project from template (starter scene with Camera3D and DirectionalLight3D).
- 2.3 Open and validate project.
- 2.4 Recent projects list (max 15, missing folders handled).
- 2.5 Safe save (temp file then rename).
- **Accept:** tests create, save, reopen, and reject invalid projects with specific messages.

### M3 — Home screen
- 3.1 `raven_launcher.py` and `editor/main.py` start the app.
- 3.2 Home screen: recent list, New Project, Open Project, Remove from list.
- 3.3 New Project dialog with live validation.
- 3.4 Opening a project opens the main window.
- **Accept:** create a project in the UI, quit, relaunch, see it in Recent, open it.

### M4 — Editor shell, scene tree, inspector, undo
- 4.1 Main window layout and saved/restored layout.
- 4.2 Undo/redo commands.
- 4.3 Scene tree panel: add (searchable dialog), delete, rename (F2), drag to reparent.
- 4.4 Inspector panel built from the property system (widget per type).
- 4.5 Console panel.
- **Accept:** add a node, change Position X in the Inspector, undo, redo, save, reopen — all correct.

### M5 — Viewport and rendering
- 5.1 `panda_driver.py` with a clean API.
- 5.2 `MeshInstance3D` (primitives first).
- 5.3 `Camera3D`, lights, `WorldEnvironment`.
- 5.4 Viewport panel with editor camera (right-mouse look, WASD, scroll), grid, click-to-select.
- 5.5 Move gizmo (rotate and scale after the MVP).
- **Accept:** add a cube from the UI, see it, select it by clicking, drag it, undo it.

### M6 — Import and files
- 6.1 File System panel (tree, new folder, new script, rename, delete with confirmation, path safety).
- 6.2 Import pipeline for GLB, glTF, PNG, JPG with a `.import.json` per asset.
- 6.3 Drag-and-drop a file into Raven (copies to `assets/`) and from the panel into the scene (creates a `MeshInstance3D`).
- **Accept:** export a model from Blender as GLB, drop it in, see it in the viewport; a bad GLB shows an error and does not crash.

### M7 — Scripts
- 7.1 Script editor panel: tabs, line numbers, Python highlighting, save, modified marker.
- 7.2 New-script template.
- 7.3 Script loader with error handling.
- 7.4 Attach/detach/open script from the Inspector.
- 7.5 Script API and `Input`.
- **Accept:** a script attached to a node moves it when the game runs; a syntax error appears in the Console with file and line.

### M8 — Play and Stop
- 8.1 `run_game.py` (no editor imports) using project settings.
- 8.2 Play saves the scene, starts the runtime process, pipes output to the Console.
- 8.3 Stop terminates it. Runtime errors show with file and line.
- **Accept:** Play opens a game window at the configured size; WASD moves the object; Stop closes it.

### M9 — Settings dialog
- 9.1 Settings dialog generated from the registry (Project / Editor tabs, search, reset to default).
- **Accept:** change window size and theme, restart, values persist and take effect.

### M10 — Installable app
- 10.1 `[project.scripts] raven = "editor.main:main"`; `pip install -e .` then `raven` works.
- 10.2 Build `Raven.app` with PyInstaller (include templates and icons).
- 10.3 Test by double-clicking on a clean user account or machine without the dev environment.
- **Accept:** the installed app completes the demo in section 12. Document the unsigned-app first-launch warning in the README.

### M11 — Demo, documentation, release notes
- 11.1 Finish `examples/mvp_demo/` and a README walkthrough.
- 11.2 `documentation/`: architecture, project format, script API, known limitations.
- 11.3 Tag `v0.1.0`.

---

## 12. The MVP demo (the proof)

Using only the installed Raven app:

1. Create project "Demo".
2. Add a Plane (floor), a `Camera3D`, a `DirectionalLight3D`.
3. Import `robot.glb` exported from Blender and place it on the floor.
4. Create `scripts/robot.py` (section 9), attach it to the robot.
5. Press Play, move the robot with WASD, press Stop.
6. Save, quit, relaunch, reopen the project, and everything is as left.

---

## 13. Quality gates (every task)

1. Tests written and passing (`pytest` output shown).
2. The feature was actually run by hand once (UI features: describe what was clicked and what happened).
3. No Panda3D imports outside the driver; no editor imports in engine/runtime.
4. Errors are caught and shown as messages, never silent and never an unhandled crash.
5. Docstrings on public classes and functions; docs updated when an API changes.
6. Git commit with a clear message.

---

## 14. AI operating rules (also save as `RULES.md`)

1. Read the existing repo before changing anything.
2. Do exactly one task per request; do not touch unrelated files.
3. No duplicate classes; follow the folder structure.
4. Write complete, runnable code. No placeholders presented as finished.
5. Never claim something works unless you ran it. Paste the test output.
6. Do not add dependencies or change architecture without writing a short decision note first.
7. If a step cannot be done as specified, stop and report the problem and options; do not silently substitute.
8. Do not overwrite working code without reviewing what it does.
9. Do not claim scripts are sandboxed.
10. Finish every response with this report:

```
FILES CREATED:
FILES MODIFIED:
TESTS RUN + RESULT:
MANUAL CHECK PERFORMED:
KNOWN LIMITATIONS:
NEXT TASK:
```

---

## 15. Prompt template for each task

```
Read RAVEN_MVP_PLAN.md and RULES.md, then inspect the current repo.
Task: <milestone and step, e.g. "M1.5 Node">.
Dependencies already complete: <list>.
Files to create or edit: <from the plan>.
Acceptance: <the milestone's Accept line, narrowed to this step>.
Write code and pytest tests, run them, fix failures, then give the report from section 14.
Do not start any other task.
```

---

## 16. Risks and fallbacks

| Risk | Fallback |
|---|---|
| Panda3D will not embed in Qt on macOS | Separate viewport window for the MVP |
| Two event loops (Qt and Panda3D) conflict | Drive Panda3D manually from a Qt timer |
| Python too slow for the viewport | Measure first; reduce draw calls; only then consider native code |
| PyInstaller app too large or fails | Try Briefcase; accept a large app size for the MVP |
| App blocked on first launch (unsigned) | Document right-click → Open; signing needs a paid Apple developer account |
| AI code the developer cannot explain | Stop; ask the AI to explain the file before continuing |
| Scope creep | Write it in `IDEAS.md` |

---

## 17. Definition of Done — MVP v0.1.0

- [ ] Installed app launches by double-click
- [ ] Create, save, reopen projects from the home screen
- [ ] Add, rename, delete, reparent nodes with undo/redo
- [ ] Inspector edits every property of the 7 MVP nodes
- [ ] GLB import by drag and drop works; bad files show errors
- [ ] Script editor creates, edits and attaches scripts
- [ ] Play/Stop runs the game in a separate window with errors in the Console
- [ ] Settings dialog works and persists
- [ ] Demo in section 12 completed in the installed app
- [ ] All tests pass; documentation written; `v0.1.0` tagged
