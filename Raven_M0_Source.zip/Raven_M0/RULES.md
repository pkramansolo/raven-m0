# Raven development rules

1. Work one milestone at a time; do not claim MVP complete from a smoke test.
2. Keep all Panda3D imports in `src/raven/engine/drivers/panda_driver.py`.
3. The editor must not be a dependency of the runtime or engine.
4. Use `pyproject.toml` as the dependency authority.
5. Run tests and report platform-specific verification separately.
6. Never execute untrusted Python project scripts without warning: they are not sandboxed.
7. Obtain approval before the next major milestone.
