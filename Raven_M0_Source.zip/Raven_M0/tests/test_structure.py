"""Headless M0 package and architecture checks."""
from pathlib import Path
import ast

ROOT = Path(__file__).resolve().parents[1]

def test_panda_imports_are_driver_only() -> None:
    """Ensure no other production module imports Panda3D."""
    for path in (ROOT / "src" / "raven").rglob("*.py"):
        if path.name == "panda_driver.py":
            continue
        tree = ast.parse(path.read_text())
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                assert all(not (alias.name.startswith("panda3d") or alias.name.startswith("direct.")) for alias in node.names), path
            if isinstance(node, ast.ImportFrom) and node.module:
                assert not (node.module.startswith("panda3d") or node.module.startswith("direct.")), path

def test_entrypoint_exists() -> None:
    """Verify the editor entrypoint and packaging metadata exist."""
    assert (ROOT / "src/raven/main.py").is_file()
    assert (ROOT / "pyproject.toml").is_file()

def test_driver_has_cube_geometry() -> None:
    """Verify the standalone renderer contains real procedural mesh geometry."""
    tree = ast.parse((ROOT / "src/raven/engine/drivers/panda_driver.py").read_text())
    assert any(isinstance(n, ast.ClassDef) and n.name == "PandaSmokeDriver" for n in ast.walk(tree))
