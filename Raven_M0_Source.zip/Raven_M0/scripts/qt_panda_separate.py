"""M0 fallback integration: Qt editor and Panda viewport in separate processes."""
import subprocess
import sys
from PySide6.QtWidgets import QApplication
from raven.editor.main_window import RavenWindow

def main() -> int:
    """Launch the renderer as a child process and terminate it with the editor."""
    app = QApplication(sys.argv)
    window = RavenWindow()
    window.console.appendPlainText("Starting Panda3D in a separate process...")
    process = subprocess.Popen([sys.executable, "-m", "raven.engine.drivers.panda_driver"])
    window.show()
    try:
        return app.exec()
    finally:
        if process.poll() is None:
            process.terminate()
            try:
                process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait()

if __name__ == "__main__":
    raise SystemExit(main())
