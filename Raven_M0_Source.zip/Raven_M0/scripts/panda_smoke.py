"""Launch a standalone real 3D cube through the renderer driver."""
from raven.engine.drivers.panda_driver import run_panda_smoke

if __name__ == "__main__":
    run_panda_smoke()
