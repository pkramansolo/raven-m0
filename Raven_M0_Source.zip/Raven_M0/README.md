# Raven — M0 technical prototype

This is **real source code** for the first milestone, not a finished game engine or installable `.dmg`.

## On your MacBook Air M4

Open Terminal in this folder. Use Python **3.11 or 3.12**, not 3.13/3.14.

```bash
conda activate sparrow
python --version
python -m pip install -e '.[dev]'
python -m pytest -q
raven-m0
```

The first command-line app opens a dockable Qt editor shell. Its center panel is intentionally a placeholder.

To test **actual 3D rendering** in a second terminal:

```bash
python -m raven.engine.drivers.panda_driver
```

The 3D window shows a rotating blue cube. Move the camera with W/A/S/D, up/down with Q/E, exit with Escape.

To test **Qt + Panda3D separate-process fallback**:

```bash
python scripts/qt_panda_separate.py
```

Closing the Qt editor should terminate its 3D child window. Verify this manually.

## M0 checklist (requires your Mac)

- [ ] Dependencies import in `sparrow`
- [ ] Qt dock windows open, move and resize
- [ ] 3D cube renders on Apple Silicon
- [ ] Camera and keyboard input respond
- [ ] 3D viewport resizes correctly
- [ ] Qt and Panda3D shut down cleanly
- [ ] Embedding via native Qt window handle evaluated
- [ ] Offscreen Qt viewport evaluated
- [ ] Integration decision recorded in `docs/architecture/decisions.md`

## Not yet included

No node system, project manager, scene persistence, GLB importer, embedded viewport, Python scripting, packaged `.app`, or `.dmg` yet. These are later milestones.
